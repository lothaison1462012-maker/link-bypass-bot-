// ============================================
// PHẦN 1: CẤU HÌNH VÀ DEPENDENCIES
// ============================================

const TelegramBot = require('node-telegram-bot-api');
const puppeteer = require('puppeteer-extra');
const StealthPlugin = require('puppeteer-extra-plugin-stealth');
const fs = require('fs');

// ====== THÔNG TIN CỦA BẠN ======
const TOKEN = '8752277916:AAGiYMqDXM1a-YdLg8d54kVMlUgwrsUORqM';
const ADMIN_ID = 8878003413;

puppeteer.use(StealthPlugin());
const bot = new TelegramBot(TOKEN, { polling: true });

// ====== FILE DỮ LIỆU ======
const DATA_FILE = 'data.json';

function loadData() {
    try {
        if (fs.existsSync(DATA_FILE)) {
            return JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
        }
    } catch (e) {}
    return { users: {}, keys: {} };
}

function saveData(data) {
    fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
}

let data = loadData();

// ====== DANH SÁCH DOMAIN HỖ TRỢ ======
const SUPPORTED_DOMAINS = [
    'link4m.com', 'link4m.net', 'link4m.org',
    'layma.net', 'layma.vn',
    'traffic',
    'short2.net', 'short2.vn', 'short2.io',
    'adf.ly', 'shorte.st', 'adlinkfly',
    'goo.gl', 'bit.ly', 'tinyurl.com', 'tinyurl.vn',
    'rb.gy', 'cutt.ly', 'ow.ly', 'is.gd', 'v.gd', 'tiny.cc'
];

function isSupportedLink(url) {
    const lower = url.toLowerCase();
    for (let domain of SUPPORTED_DOMAINS) {
        if (lower.includes(domain)) return true;
    }
    return false;
}

// ====== HÀM LOG ======
const c = {
    reset: '\x1b[0m',
    bright: '\x1b[1m',
    green: '\x1b[32m',
    yellow: '\x1b[33m',
    red: '\x1b[31m',
    cyan: '\x1b[36m',
    magenta: '\x1b[35m'
};

function log(msg, type = 'info') {
    const now = new Date().toLocaleTimeString();
    const prefix = {
        'start': '🚀 START',
        'info': 'ℹ️ INFO',
        'success': '✅ SUCCESS',
        'error': '❌ ERROR',
        'warning': '⚠️ WARNING',
        'bot': '🤖 BOT',
        'pp': '🖥️ PP',
        'bypass': '🔓 BYPASS',
        'admin': '👑 ADMIN'
    } [type] || '📌 LOG';
    
    const color = {
        'start': c.green,
        'success': c.green,
        'error': c.red,
        'warning': c.yellow,
        'bot': c.magenta,
        'pp': c.cyan,
        'bypass': c.green,
        'admin': c.yellow
    } [type] || c.cyan;
    
    console.log(`${c.cyan}[${now}]${c.reset} ${color}${c.bright}${prefix}${c.reset} ${msg}`);
}

// ====== HÀM KEY ======
function generateKey() {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let key = '';
    for (let i = 0; i < 6; i++) {
        key += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return key;
}

function isValidKey(key) {
    return data.keys[key] && data.keys[key].uses > 0;
}

function useKey(key, userId) {
    if (!data.keys[key]) return false;
    if (data.keys[key].uses <= 0) return false;
    data.keys[key].uses--;
    data.keys[key].usedBy.push(userId);
    saveData(data);
    return true;
}

function getFreeUses(userId) {
    if (!data.users[userId]) {
        data.users[userId] = { freeUses: 2, totalBypassed: 0 };
        saveData(data);
    }
    return data.users[userId].freeUses;
}

function useFreeUses(userId) {
    if (!data.users[userId]) {
        data.users[userId] = { freeUses: 2, totalBypassed: 0 };
    }
    if (data.users[userId].freeUses <= 0) return false;
    data.users[userId].freeUses--;
    data.users[userId].totalBypassed++;
    saveData(data);
    return true;
}// ============================================
// PHẦN 2: HÀM BYPASS
// ============================================

async function bypassLink(url, chatId, userId, username) {
    const startTime = Date.now();
    let browser = null;
    
    try {
        log(`📥 ${username} (${userId}) bypass: ${url}`, 'bot');
        await bot.sendMessage(chatId, '🔄 Đang xử lý link...\n⏳ Vui lòng đợi 30-60 giây.');
        
        browser = await puppeteer.launch({
            headless: true,
            args: [
                '--no-sandbox',
                '--disable-setuid-sandbox',
                '--disable-dev-shm-usage',
                '--disable-accelerated-2d-canvas',
                '--disable-gpu',
                '--window-size=1280,720'
            ]
        });
        
        const page = await browser.newPage();
        await page.setUserAgent('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36');
        
        await page.goto(url, {
            waitUntil: 'networkidle2',
            timeout: 60000
        });
        
        const pageInfo = await page.evaluate(() => {
            return {
                title: document.title || '',
                url: window.location.href,
                hasCaptcha: !!document.querySelector('.recaptcha-checkbox, #recaptcha-anchor, .g-recaptcha'),
                hasTimer: !!document.querySelector('[id*="time"], [class*="time"], [id*="count"], [class*="count"], [id*="timer"], [class*="timer"]'),
                hasButton: !!document.querySelector('a[href*="#"], button:not([disabled]), input[type="submit"]')
            };
        });
        
        log(`📄 Title: ${pageInfo.title}`, 'info');
        log(`🔐 Captcha: ${pageInfo.hasCaptcha}`, 'info');
        log(`⏱️ Timer: ${pageInfo.hasTimer}`, 'info');
        log(`🔘 Button: ${pageInfo.hasButton}`, 'info');
        
        if (pageInfo.hasCaptcha) {
            log('⚠️ PHÁT HIỆN CAPTCHA!', 'warning');
            await bot.sendMessage(chatId, '⚠️ Link yêu cầu captcha.\n🔄 Bot đang thử bypass...');
        }
        
        // ===== 1. CLICK NÚT =====
        try {
            const clicked = await page.evaluate(() => {
                const btns = document.querySelectorAll('a, button, input[type="submit"]');
                for (let btn of btns) {
                    const text = (btn.innerText || btn.value || '').toLowerCase();
                    if (text.includes('click') || text.includes('tiếp') || text.includes('continue') || text.includes('submit') || text.includes('next') || text.includes('here') || text.includes('vào') || text.includes('bấm')) {
                        btn.click();
                        return true;
                    }
                }
                return false;
            });
            
            if (clicked) {
                log('✅ Đã click nút!', 'success');
                await bot.sendMessage(chatId, '✅ Đã click nút tiếp tục!');
            } else {
                log('⚠️ Không tìm thấy nút', 'warning');
            }
        } catch (e) {}
        
        // ===== 2. CHỜ TIMER =====
        log('⏳ Đang chờ timer...', 'pp');
        await bot.sendMessage(chatId, '⏳ Đang chờ timer...');
        
        try {
            await page.waitForFunction(() => {
                const els = document.querySelectorAll('[id*="time"], [class*="time"], [id*="count"], [class*="count"], [id*="timer"], [class*="timer"]');
                for (let el of els) {
                    const txt = el.textContent || '';
                    const match = txt.match(/\b\d+\b/);
                    if (match && parseInt(match[0]) <= 2) {
                        return true;
                    }
                }
                return true;
            }, { timeout: 60000 });
            log('✅ Timer đã hết!', 'success');
            await bot.sendMessage(chatId, '✅ Đã hết timer!');
        } catch (e) {
            log(`⚠️ Lỗi timer: ${e.message}`, 'warning');
            await page.waitForTimeout(5000);
        }
        
        // ===== 3. TÌM LINK ĐÍCH =====
        log('🔍 Đang tìm link đích...', 'pp');
        await bot.sendMessage(chatId, '🔍 Đang tìm link gốc...');
        
        const finalUrl = await page.evaluate(() => {
            const skipDomains = [
                'link4m', 'layma', 'traffic', 'short2',
                'shorte', 'adf.ly', 'bit.ly', 'tinyurl',
                'goo.gl', 'rb.gy', 'cutt.ly', 'ow.ly',
                'is.gd', 'v.gd', 'tiny.cc', 'adlinkfly'
            ];
            
            const meta = document.querySelector('meta[http-equiv="refresh"]');
            if (meta) {
                const content = meta.getAttribute('content') || '';
                const match = content.match(/url=(.*)/i);
                if (match) return match[1];
            }
            
            const links = document.querySelectorAll('a[href]');
            for (let link of links) {
                const href = link.href;
                if (!href || href.includes('javascript:') || href.includes('#')) continue;
                let shouldSkip = false;
                for (let d of skipDomains) {
                    if (href.toLowerCase().includes(d)) { shouldSkip = true; break; }
                }
                if (!shouldSkip && href.startsWith('http')) {
                    return href;
                }
            }
            
            const scripts = document.querySelectorAll('script');
            for (let script of scripts) {
                const content = script.textContent || '';
                const match = content.match(/window\.location\s*=\s*["'](.*?)["']/);
                if (match) return match[1];
            }
            
            return null;
        });
        
        const elapsed = ((Date.now() - startTime) / 1000).toFixed(1);
        
        if (finalUrl) {
            log(`✅ THÀNH CÔNG! Link: ${finalUrl}`, 'bypass');
            log(`⏱️ Thời gian: ${elapsed}s`, 'success');
            
            await bot.sendMessage(chatId,
                `✅ **THÀNH CÔNG!**\n\n` +
                `🔗 **Link gốc:**\n${finalUrl}\n\n` +
                `⏱️ Thời gian: ${elapsed}s`,
                { parse_mode: 'Markdown' }
            );
            
            if (!data.users[userId]) {
                data.users[userId] = { freeUses: 0, totalBypassed: 0 };
            }
            data.users[userId].totalBypassed++;
            saveData(data);
            
            return true;
        } else {
            log('❌ KHÔNG TÌM THẤY LINK ĐÍCH!', 'error');
            await bot.sendMessage(chatId,
                `❌ **KHÔNG THỂ BYPASS!**\n\n` +
                `⚠️ Nguyên nhân có thể:\n` +
                `• Link yêu cầu captcha\n` +
                `• Link đã hết hạn\n` +
                `• Link yêu cầu tương tác thủ công\n\n` +
                `⏱️ Thời gian: ${elapsed}s`,
                { parse_mode: 'Markdown' }
            );
            return false;
        }
        
    } catch (error) {
        log(`❌ LỖI: ${error.message}`, 'error');
        await bot.sendMessage(chatId, `❌ Lỗi: ${error.message}`);
        return false;
    } finally {
        if (browser) {
            await browser.close();
            log('🔄 Đã đóng browser', 'info');
        }
    }
}// ============================================
// PHẦN 3: LỆNH BOT + XỬ LÝ TIN NHẮN + START
// ============================================

// ===== LỆNH USER =====
bot.onText(/\/start/, (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;
    const username = msg.from.username || msg.from.first_name || 'User';
    
    log(`👤 ${username} (${userId}) đã start bot`, 'bot');
    
    const freeUses = getFreeUses(userId);
    
    bot.sendMessage(chatId,
        `🤖 **Link Bypass Bot**\n\n` +
        `Chào ${username}! 👋\n\n` +
        `📊 **Lượt free còn lại:** ${freeUses}/2\n\n` +
        `📌 **Hỗ trợ các link:**\n` +
        `• link4m.com / .net / .org\n` +
        `• layma.net\n` +
        `• short2.net\n` +
        `• traffic\n` +
        `• Các link rút gọn khác\n\n` +
        `📌 **Cách dùng:**\n` +
        `• Gửi link cần bypass\n` +
        `• Bot xử lý trong 30-60 giây\n` +
        `• Nhận link gốc\n\n` +
        `🔑 **Nhập key 6 ký tự** để nạp thêm lượt\n\n` +
        `📖 **Lệnh:** /help - Trợ giúp`,
        { parse_mode: 'Markdown' }
    );
});

bot.onText(/\/help/, (msg) => {
    const chatId = msg.chat.id;
    bot.sendMessage(chatId,
        `📖 **Hướng Dẫn Chi Tiết**\n\n` +
        `1️⃣ Gửi link cần bypass\n` +
        `2️⃣ Bot tự động xử lý\n` +
        `3️⃣ Nhận link gốc sau 30-60s\n\n` +
        `🔑 **Key:**\n` +
        `• 6 ký tự (chữ + số)\n` +
        `• Nhập key để nạp thêm lượt\n` +
        `• Key chỉ có admin tạo\n\n` +
        `📌 **Hỗ trợ:**\n` +
        `• link4m (com/net/org)\n` +
        `• layma.net\n` +
        `• short2.net\n` +
        `• traffic\n` +
        `• Và nhiều shortener khác`,
        { parse_mode: 'Markdown' }
    );
});

bot.onText(/\/me/, (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;
    
    if (!data.users[userId]) {
        data.users[userId] = { freeUses: 2, totalBypassed: 0 };
        saveData(data);
    }
    
    const user = data.users[userId];
    
    bot.sendMessage(chatId,
        `👤 **Thông Tin Của Bạn**\n\n` +
        `🆔 ID: ${userId}\n` +
        `📊 Lượt free còn: ${user.freeUses}/2\n` +
        `✅ Đã bypass thành công: ${user.totalBypassed} link`,
        { parse_mode: 'Markdown' }
    );
});

bot.onText(/\/status/, (msg) => {
    const chatId = msg.chat.id;
    const uptime = process.uptime();
    const h = Math.floor(uptime / 3600);
    const m = Math.floor((uptime % 3600) / 60);
    const s = Math.floor(uptime % 60);
    
    const totalUsers = Object.keys(data.users).length;
    const totalKeys = Object.keys(data.keys).length;
    
    bot.sendMessage(chatId,
        `📊 **Trạng Thái Bot**\n\n` +
        `🟢 Bot: Đang chạy\n` +
        `⏱️ Uptime: ${h}h ${m}m ${s}s\n` +
        `👥 Người dùng: ${totalUsers}\n` +
        `🔑 Tổng key: ${totalKeys}\n` +
        `💾 Memory: ${(process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2)} MB`,
        { parse_mode: 'Markdown' }
    );
});

// ===== LỆNH ADMIN =====
function isAdmin(userId) {
    return userId === ADMIN_ID;
}

bot.onText(/\/tk(?:\s+(.+))?/, (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;
    
    if (!isAdmin(userId)) {
        bot.sendMessage(chatId, '❌ Bạn không có quyền sử dụng lệnh này!');
        return;
    }
    
    const name = msg.match[1] || 'Key mới';
    const key = generateKey();
    const uses = 1;
    
    data.keys[key] = {
        name: name,
        uses: uses,
        createdBy: userId,
        createdAt: new Date().toISOString(),
        usedBy: []
    };
    saveData(data);
    
    log(`👑 Admin tạo key: ${key} - ${name}`, 'admin');
    
    bot.sendMessage(chatId,
        `🔑 **Key mới đã tạo!**\n\n` +
        `📌 Key: \`${key}\`\n` +
        `📝 Tên: ${name}\n` +
        `📊 Số lượt: ${uses}\n\n` +
        `📋 Copy và gửi cho người dùng.`,
        { parse_mode: 'Markdown' }
    );
});

bot.onText(/\/listkey/, (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;
    
    if (!isAdmin(userId)) {
        bot.sendMessage(chatId, '❌ Bạn không có quyền sử dụng lệnh này!');
        return;
    }
    
    const keys = Object.keys(data.keys);
    if (keys.length === 0) {
        bot.sendMessage(chatId, '📭 Chưa có key nào được tạo.');
        return;
    }
    
    let msgText = '📋 **Danh sách key:**\n\n';
    for (let key of keys) {
        const info = data.keys[key];
        const status = info.uses > 0 ? `✅ Còn ${info.uses} lượt` : '❌ Hết lượt';
        msgText += `🔑 \`${key}\` - ${info.name} - ${status}\n`;
    }
    
    bot.sendMessage(chatId, msgText, { parse_mode: 'Markdown' });
});

bot.onText(/\/stats/, (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;
    
    if (!isAdmin(userId)) {
        bot.sendMessage(chatId, '❌ Bạn không có quyền sử dụng lệnh này!');
        return;
    }
    
    const totalUsers = Object.keys(data.users).length;
    let totalBypassed = 0;
    for (let uid in data.users) {
        totalBypassed += data.users[uid].totalBypassed || 0;
    }
    const totalKeys = Object.keys(data.keys).length;
    let totalUses = 0;
    for (let key in data.keys) {
        totalUses += data.keys[key].uses;
    }
    
    bot.sendMessage(chatId,
        `📊 **Thống Kê Bot**\n\n` +
        `👥 Tổng người dùng: ${totalUsers}\n` +
        `✅ Tổng bypass thành công: ${totalBypassed}\n` +
        `🔑 Tổng key đã tạo: ${totalKeys}\n` +
        `📌 Tổng lượt key còn: ${totalUses}`,
        { parse_mode: 'Markdown' }
    );
});

// ===== NHẬN KEY HOẶC LINK =====
bot.on('message', async (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;
    const text = msg.text || '';
    const username = msg.from.username || msg.from.first_name || 'User';
    
    if (text.startsWith('/')) return;
    
    // Kiểm tra key
    const keyMatch = text.match(/^[A-Za-z0-9]{6}$/);
    if (keyMatch) {
        const key = keyMatch[0];
        if (isValidKey(key)) {
            if (useKey(key, userId)) {
                if (!data.users[userId]) {
                    data.users[userId] = { freeUses: 2, totalBypassed: 0 };
                }
                data.users[userId].freeUses += 1;
                saveData(data);
                
                log(`🔑 ${username} (${userId}) đã nhập key: ${key}`, 'success');
                bot.sendMessage(chatId,
                    `✅ **Nạp key thành công!**\n\n` +
                    `🔑 Key: \`${key}\`\n` +
                    `📊 Bạn được +1 lượt bypass\n` +
                    `📌 Số lượt hiện tại: ${data.users[userId].freeUses}`,
                    { parse_mode: 'Markdown' }
                );
            }
        } else {
            bot.sendMessage(chatId, '❌ Key không hợp lệ hoặc đã hết lượt!');
        }
        return;
    }
    
    // Kiểm tra link
    if (isSupportedLink(text)) {
        const freeUses = getFreeUses(userId);
        
        if (freeUses <= 0) {
            bot.sendMessage(chatId,
                `❌ **Bạn đã hết lượt free!**\n\n` +
                `📊 Lượt free: 0/2\n\n` +
                `🔑 Nhập key 6 ký tự để nạp thêm lượt.\n` +
                `📌 Liên hệ admin để lấy key.`,
                { parse_mode: 'Markdown' }
            );
            return;
        }
        
        if (!useFreeUses(userId)) {
            bot.sendMessage(chatId, '❌ Lỗi: Không thể trừ lượt. Vui lòng thử lại!');
            return;
        }
        
        const success = await bypassLink(text, chatId, userId, username);
        
        if (!success) {
            if (!data.users[userId]) {
                data.users[userId] = { freeUses: 0, totalBypassed: 0 };
            }
            data.users[userId].freeUses += 1;
            saveData(data);
            bot.sendMessage(chatId, '🔄 Đã hoàn lại 1 lượt do bypass thất bại.');
        }
        
    } else if (text.length > 5) {
        bot.sendMessage(chatId,
            `❌ Vui lòng gửi link hoặc key!\n\n` +
            `📌 **Link hỗ trợ:**\n` +
            `• link4m.com / .net / .org\n` +
            `• layma.net\n` +
            `• short2.net\n` +
            `• traffic\n` +
            `• Các shortener khác\n\n` +
            `🔑 **Key:** 6 ký tự (abc123)`,
            { parse_mode: 'Markdown' }
        );
    }
});

// ===== START BOT =====
log('========================================', 'start');
log('🚀 BOT BYPASS ĐANG KHỞI ĐỘNG...', 'start');
log('========================================', 'start');

log(`👑 Admin ID: ${ADMIN_ID}`, 'admin');
log(`🤖 Token: ${TOKEN.substring(0, 10)}...`, 'info');
log(`📦 Node.js: ${process.version}`, 'info');
log(`📁 Thư mục: ${__dirname}`, 'info');

log('✅ Bot đã sẵn sàng!', 'success');
log('📌 Hỗ trợ: link4m | layma | short2 | traffic | v.v.', 'info');